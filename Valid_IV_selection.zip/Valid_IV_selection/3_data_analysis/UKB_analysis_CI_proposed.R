

rm(list = ls(all.names = TRUE))
library(nleqslv)
source("C:/Users/81908/Desktop/D1_Orihara/GMM_NCO.R")
a_data_ <- read.csv("C:/Users/81908/Desktop/D1_Orihara/4_UK_Biobank/analysis_data/a_mat.csv")
a_data_ <- a_data_[,-1]
##ready for analysis
a_data <- subset(a_data_[,-c(81,83)],a_data_[,1]!="2213375"&
				   a_data_[,1]!="4837207"&
				   a_data_[,1]!="5012899"&
				   a_data_[,1]!="5609417"&
				   a_data_[,1]!="5796059"&
				   a_data_[,1]!="1520609"&
				   a_data_[,1]!="1694302"&
				   a_data_[,1]!="2213375"&
				   a_data_[,1]!="2399607"&
				   a_data_[,1]!="3297537"&
				   a_data_[,1]!="4605522"&
				   a_data_[,1]!="4837207"&
				   a_data_[,1]!="5012899"&
				   a_data_[,1]!="5609417"&
				   a_data_[,1]!="5796059")


##Variables
a_data_anl <- na.omit(a_data[a_data[,81]>=0,])
nn <- nrow(a_data_anl)

TT <- a_data_anl[,80]
ZZ <- a_data_anl[,3:79]
YY <- a_data_anl[,81]
ZZ[,c(2,4,9,10,13,17,21,24,28,29,35,36,38,40,41,42,46,47,49,52,55,56,58,60,61,62,67,69,70,72,73,75,76)] <- abs(ZZ[,c(2,4,9,10,13,17,21,24,28,29,35,36,38,40,41,42,46,47,49,52,55,56,58,60,61,62,67,69,70,72,73,75,76)]-2)

ZZs <- as.matrix(ZZ)%*%solve(sqrt(diag(diag(var(ZZ)))))

##NCO (Standardization)
MM <- a_data_anl[,82]-mean(a_data_anl[,82])


#Proposed GMM method
TT_1 <- cbind(1,TT)

gamma <- NCO_func(0.1,ZZs,MM,TT)
kekka <- GMM_func(gamma,ZZs,TT,YY)

beta_GMM <- kekka[[1]][2]
sigma1b <- kekka[[2]][2,2]

print(c(exp(6.5*beta_GMM),exp(-1.96*sigma1b)*exp(6.5*beta_GMM),exp(1.96*sigma1b)*exp(6.5*beta_GMM)))

#pdf("C:/Users/81908/Desktop/D1_Orihara/_Projects/zu7.pdf",width=16,height=10)
Choice_func(0.1,ZZs,MM)
#dev.off()






