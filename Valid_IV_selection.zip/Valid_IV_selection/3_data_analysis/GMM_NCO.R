
###PROGRAMS###############

### IV selection by NCO ###

NCO_func <- function(alpha,ZZ,MM,TT){

tau <- 1e-6
kappa1 <- 1e8
kappa2 <- 0.001

nn <- length(TT)

##Step 1
ww1 <- abs(t(ZZ)%*%MM)/nn
ww=abs(qnorm(alpha/(2*ncol(ZZ))))*sd(MM)/sqrt(nn)
Ind1 <- pnorm(ww1+ww,sd=tau)*pnorm(ww-ww1,sd=tau); cInd1 <- 1-Ind1

GMM_vec2 <- cbind(ZZ*c(Ind1))
cGMM_mat <- kappa1*diag(c(cInd1))
gan_mat <- t(GMM_vec2)%*%GMM_vec2+cGMM_mat

##Estimates of Step 1
gamma <- solve(gan_mat)%*%(c(t(TT)%*%GMM_vec2)+kappa2*c(cInd1))
return(gamma)
}

##plot(ww1,xlim=c(1,77),xaxp=c(1,77,38),cex.axis=1)
##plot(Ind1,xlim=c(1,77),xaxp=c(1,77,38),cex.axis=1,ylim=c(0,1))
##plot(gamma,xlim=c(1,77),xaxp=c(1,77,38),cex.axis=1)

### End of IV selection by NCO ###


### GMM proposed by Orihara et al. ###

GMM_func <- function(gamma,ZZ,TT,YY){

nn <- length(TT)

GMM_mat <- t(cbind(1,ZZ%*%gamma))
TT_1 <- cbind(1,TT)

##Step 2
optim_func3 <- function(beta){
  EstEq <- GMM_mat%*%(YY-exp(TT_1%*%beta))   ##log linear model
  return(EstEq)
}
##Estimate of Step 2
beta_OT <- nleqslv(c(0,0),optim_func3)$x

##Varianve covariance matrix
Sigma3 <- ((c(YY-exp(TT_1%*%beta_OT))*GMM_mat)%*%t(c(YY-exp(TT_1%*%beta_OT))*GMM_mat))/nn
Gamma3 <- (-(c(exp(TT_1%*%beta_OT))*GMM_mat)%*%TT_1)/nn
sigma3b <- (t(solve(Gamma3))%*%Sigma3%*%solve(Gamma3))/nn

##Point estimate
return(list(beta_OT,sigma3b))
}


Choice_func <- function(alpha,ZZ,MM){
  tau <- 1e-6
  nn <- length(MM)

  ww1 <- abs(t(ZZ)%*%MM)/nn
  ww=abs(qnorm(alpha/(2*ncol(ZZ))))*sd(MM)/sqrt(nn)
  Ind1 <- pnorm(ww1+ww,sd=tau)*pnorm(ww-ww1,sd=tau)
  
  if(ncol(ZZ)%%2==0) plot(Ind1,xlim=c(0,ncol(ZZ)),xaxp=c(1,ncol(ZZ)-1,(ncol(ZZ)/2-1)),cex.axis=1,ylim=c(0,1))
  else plot(Ind1,xlim=c(0,ncol(ZZ)),xaxp=c(1,ncol(ZZ),(ncol(ZZ)-1)/2),cex.axis=1,ylim=c(0,1))
}

### End of GMM ###

##########################
