

#rm(list = ls(all.names = TRUE))
#library(nleqslv)
#a_data_ <- read.csv("C:/Users/81908/Desktop/D1_Orihara/4_UK_Biobank/analysis_data/a_mat.csv")
#a_data_ <- a_data_[,-1]
##ready for analysis
a_data <- subset(a_data_[,-c(81,83)],a_data_[,1]!="2213375"&
				   a_data_[,1]!="4837207"&
				   a_data_[,1]!="5012899"&
				   a_data_[,1]!="5609417"&
				   a_data_[,1]!="5796059"&
				   a_data_[,1]!="1520609"&
				   a_data_[,1]!="1694302"&
				   a_data_[,1]!="2213375"&
				   a_data_[,1]!="2399607"&
				   a_data_[,1]!="3297537"&
				   a_data_[,1]!="4605522"&
				   a_data_[,1]!="4837207"&
				   a_data_[,1]!="5012899"&
				   a_data_[,1]!="5609417"&
				   a_data_[,1]!="5796059")


##Variables
a_data_anl <- na.omit(a_data[a_data[,81]>=0,])
nn <- nrow(a_data_anl)

TT <- a_data_anl[,80]
ZZ <- a_data_anl[,3:79]
YY <- a_data_anl[,81]
ZZ[,c(2,4,9,10,13,17,21,24,28,29,35,36,38,40,41,42,46,47,49,52,55,56,58,60,61,62,67,69,70,72,73,75,76)] <- abs(ZZ[,c(2,4,9,10,13,17,21,24,28,29,35,36,38,40,41,42,46,47,49,52,55,56,58,60,61,62,67,69,70,72,73,75,76)]-2)

ZZs <- as.matrix(ZZ)%*%solve(sqrt(diag(diag(var(ZZ)))))

#GMM
TT_1 <- cbind(1,TT)



##Estimates of Step 1
GMM_vec3 <- ZZs
gan_mat <- t(GMM_vec3)%*%GMM_vec3

##Estimates of Step 1
gamma_ <- solve(gan_mat)%*%(c(t(TT)%*%GMM_vec3))
#plot(gamma_)

##Step 2
GMM_mat <- rbind(1,t(ZZs%*%gamma_))

##Estimate
optim_func1 <- function(beta){
  EstEq <- GMM_mat%*%(YY-exp(TT_1%*%beta))     ##log linear model
  return(EstEq)
}
beta_GMM <- nleqslv(c(0,0),optim_func1)$x

##Variance covariance matrix
Sigma1 <- ((c(YY-exp(TT_1%*%beta_GMM))*GMM_mat)%*%t(c(YY-exp(TT_1%*%beta_GMM))*GMM_mat))/nn
Gamma1 <- (-(c(exp(TT_1%*%beta_GMM))*GMM_mat)%*%TT_1)/nn

sigma1b <- ((solve(Gamma1))%*%Sigma1%*%t(solve(Gamma1)))[2,2]



#Logis reg.
##Estimate
kk <- glm(YY~TT,family=binomial)
beta_LR <- summary(kk)[[12]][,1]
LR_sa <- log(exp(c(1,25)%*%beta_LR)/(1+exp(c(1,25)%*%beta_LR)))-log(exp(c(1,18.5)%*%beta_LR)/(1+exp(c(1,18.5)%*%beta_LR)))

##Variance covariance matrix
vcov <- nn*vcov(kk)
sigma2b1_ <- (1/1+exp(c(1,25)%*%beta_LR))^2*c(1,25)%*%vcov%*%c(1,25)
sigma2b2_ <- (1/1+exp(c(1,18.5)%*%beta_LR))^2*c(1,18.5)%*%vcov%*%c(1,18.5)
sigma2b <- (sigma2b1_+sigma2b2_)/nn



#2SRI
##Estimate
res1 <- lm(TT~ZZs)$resi
##alp <- lm(TT_~as.matrix(GMM_vec3%*%rep(1,77)))$coef
##res1 <- TT-cbind(1,as.matrix(ZZs%*%rep(1,77)))%*%alp
kk <- glm(YY~TT+res1,family=binomial)
beta_2S <- summary(kk)[[12]][,1]
S2_sa <- log(exp(c(1,25,0)%*%beta_2S)/(1+exp(c(1,25,0)%*%beta_2S)))-log(exp(c(1,18.5,0)%*%beta_2S)/(1+exp(c(1,18.5,0)%*%beta_2S)))

##Variance covariance matrix
vcov <- nn*vcov(kk)
sigma5b1_ <- (1/1+exp(c(1,25,0)%*%beta_2S))^2*c(1,25,0)%*%vcov%*%c(1,25,0)
sigma5b2_ <- (1/1+exp(c(1,18.5,0)%*%beta_2S))^2*c(1,18.5,0)%*%vcov%*%c(1,18.5,0)
sigma5b <- (sigma5b1_+sigma5b2_)/nn



##Orihara et al., 2022
#From here, QAIC & QBIC
QIC_func1 <- function(XX1,XX2){

XX_1 <- cbind(XX1)
XX_2 <- cbind(XX2)

lng <- 2+ncol(XX_1)+ncol(XX_2)
ini <- rep(0,lng)

liml_func <- function(theta){
  alpha <- theta[1:(ncol(XX_1)+1)]; beta <- theta[(ncol(XX_1)+2):(ncol(XX_1)+ncol(XX_2)+2)]
  sigma <- theta[length(ini)+1]; rho <- theta[length(ini)+2]
  
  rho2_ <- 1-rho^2
  rho2__ <- replace(rho2_,0.05>rho2_,0.05)
  rho2 <- replace(rho2_,0.95<rho2__,0.95)
  
  nprob1_ <- pnorm((cbind(1,XX_2)%*%beta+rho*(TT-cbind(1,XX_1)%*%alpha))/sqrt(rho2))
  nprob0_ <- 1-pnorm((cbind(1,XX_2)%*%beta+rho*(TT-cbind(1,XX_1)%*%alpha))/sqrt(rho2))
  
  nprob1 <- replace(nprob1_,nprob1_<=0,2^-1074)
  nprob0 <- replace(nprob0_,nprob0_<=0,2^-1074)
  
  llik <- c(YY*log(nprob1)+(1-YY)*log(nprob0)-(TT-cbind(1,XX_1)%*%alpha)^2/(2*sigma^2)-log(sqrt(2*pi*sigma^2)))
  
  return(-sum(llik))
}
YY_coef_2 <- optim(par=c(ini,1,0.1),fn=liml_func,method="L-BFGS-B",lower=c(rep(-Inf,length(ini)),sqrt(1),-0.95),upper=c(rep(Inf,length(ini)),sqrt(5),0.95))$par
YY_para2 <- length(YY_coef_2)

alpha <- YY_coef_2[1:(ncol(XX_1)+1)]; beta <- YY_coef_2[(ncol(XX_1)+2):(ncol(XX_1)+ncol(XX_2)+2)]
sigma <- YY_coef_2[length(ini)+1]; rho <- YY_coef_2[length(ini)+2]
  
nprob1_ <- pnorm((cbind(1,XX_2)%*%beta+rho*(TT-cbind(1,XX_1)%*%alpha))/sqrt(1-rho^2))
nprob0_ <- 1-pnorm((cbind(1,XX_2)%*%beta+rho*(TT-cbind(1,XX_1)%*%alpha))/sqrt(1-rho^2))

nprob1 <- replace(nprob1_,nprob1_<=0,2^-1074)
nprob0 <- replace(nprob0_,nprob0_<=0,2^-1074)


ndens <- c(dnorm((cbind(1,XX_2)%*%beta+rho*(TT-cbind(1,XX_1)%*%alpha))/sqrt(1-rho^2)))

sigma11 <- c(YY/nprob1-(1-YY)/nprob0)*ndens*cbind(1,XX_2)/sqrt(1-rho^2)
sigma22 <- (c(TT-cbind(1,XX_1)%*%alpha)/sigma^2-c(YY/nprob1-(1-YY)/nprob0)*rho*ndens/sqrt(1-rho^2))*cbind(1,XX_1)

Sigma2 <- cbind(sigma11,sigma22)
Sigma3 <- solve(t(Sigma2)%*%Sigma2/nn)

return(list(alpha,beta,sigma,rho,Sigma3))
}
IC01 <- QIC_func1(XX1=ZZs,XX2=TT)

beta_OT2 <- IC01[[2]]
OT2_sa <- log(exp(c(1,25)%*%beta_OT2)/(1+exp(c(1,25)%*%beta_OT2)))-log(exp(c(1,18.5)%*%beta_OT2)/(1+exp(c(1,18.5)%*%beta_OT2)))

##Variance covariance matrix
vcov <- IC01[[5]][1:2,1:2]
sigma4b1_ <- (1/1+exp(c(1,25)%*%beta_OT2))^2*c(1,25)%*%vcov%*%c(1,25)
sigma4b2_ <- (1/1+exp(c(1,18.5)%*%beta_OT2))^2*c(1,18.5)%*%vcov%*%c(1,18.5)
sigma4b <- (sigma4b1_+sigma4b2_)/nn


##Confidence intervals
print(c(exp(6.5*beta_GMM[2]),exp(-1.96*sigma1b/nn)*exp(6.5*beta_GMM[2]),exp(1.96*sigma1b/nn)*exp(6.5*beta_GMM[2])))
print(c(exp(LR_sa),exp(-1.96*sigma2b)*exp(LR_sa),exp(1.96*sigma2b)*exp(LR_sa)))
print(c(exp(S2_sa),exp(-1.96*sigma5b)*exp(S2_sa),exp(1.96*sigma5b)*exp(S2_sa)))
print(c(exp(OT2_sa),exp(-1.96*sigma4b)*exp(OT2_sa),exp(1.96*sigma4b)*exp(OT2_sa)))







