

library(bigsnpr)
rm(list = ls(all.names = TRUE))

##xx <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank2/_gfetch/ukb22828_c1_b0_v3_ID.sample",header=T)


##For BMI
#list_snp_id <- list(c("1_96924097_C_T","1_50559820_C_T","1_78446761_G_A","1_75002193_G_A","1_110154688_T_C","1_201784287_A_C","1_72751185_T_C","1_177889480_A_G","1_49589847_A_G"))
#list_snp_id <- list(c("2_59305625_T_C","2_25150296_A_G","2_26928811_G_A","2_63053048_G_A","2_632348_A_G","2_181550962_C_T","2_143043285_C_T","2_213413231_G_A"))
#list_snp_id <- list(c("3_85807590_T_G","3_185824004_T_C","3_141275436_G_T","3_61236462_C_T","3_81792112_C_A","3_25106437_A_G"))
#list_snp_id <- list(c("4_145659064_T_C","4_45182527_A_G","4_103188709_C_T","4_77129568_C_G"))
#list_snp_id <- list(c("5_75015242_T_G"))
#list_snp_id <- list(c("6_163033350_A_G","6_40348653_A_G","6_34563164_A_G","6_50845490_A_G","6_108977663_T_C"))
#list_snp_id <- list(c("7_75163169_A_G","7_76608143_C_T"))
#list_snp_id <- list(c("8_76806584_T_C","8_85079709_T_C"))
#list_snp_id <- list(c("9_129460914_A_G","9_28414339_A_G","9_120378483_T_C","9_15634326_T_C","9_111932342_C_T"))
#list_snp_id <- list(c("10_104869038_T_C","10_102395440_T_C","10_87410904_A_G","10_114758349_C_T"))
#list_snp_id <- list(c("11_27684517_A_G","11_115022404_A_G","11_43864278_T_C","11_47650993_C_T","11_8673939_C_G"))
#list_snp_id <- list(c("12_122781897_G_A","12_50247468_G_A"))
#list_snp_id <- list(c("13_54102206_G_A","13_28020180_G_A"))
#list_snp_id <- list(c("14_25928179_C_A","14_30515112_C_T","14_29736838_C_A","14_79899454_C_T"))
#list_snp_id <- list(c("15_68077168_T_C","15_51748610_A_G"))
#list_snp_id <- list(c("16_19935389_G_A","16_53803574_T_A","16_28333411_G_A","16_28889486_C_A","16_3627358_C_T","16_31129895_A_G"))
#list_snp_id <- list(c("17_5283252_A_G","17_78615571_G_A"))
#list_snp_id <- list(c("18_21104888_C_T","18_57829135_T_C","18_56883319_T_G"))

list_snp_id <- list(c("19_18454825_A_G","19_47569003_G_A","19_46202172_C_T","19_45395619_A_G","19_34309532_A_G"))
#list_snp_id <- list(c("21_40291740_T_C"))


##For NMSC
#list_snp_id <- list(c("15_28230318_C_T"))
#list_snp_id <- list(c("20_33171772_G_A"))



snp_readBGEN(
  bgenfiles="C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank2/_gfetch/ukb22828_c19_b0_v3.bgen",
  backingfile="C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank2/_gfetch/extract_c19",
  list_snp_id=list_snp_id,
  bgi_dir = "C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank2/_gfetch",
  ncores=10
)

##readRDS("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank2/_gfetch/extract_c##.rds")
##readRDS("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank2/_gfetch/ukb22828_c19_b0_v3_not_found.rds")

##ukb_imp <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank2/_gfetch/extract_c3.rds")




