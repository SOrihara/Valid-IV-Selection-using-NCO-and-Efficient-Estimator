

rm(list = ls(all.names = TRUE))
library(nleqslv)
library(Hmisc)
a_data_ <- read.csv("C:/Users/81908/Desktop/D1_Orihara/4_UK_Biobank/analysis_data/a_mat.csv")
a_data_ <- a_data_[,-1]
##ready for analysis
a_data <- subset(a_data_[,-c(81,83)],a_data_[,1]!="2213375"&
				   a_data_[,1]!="4837207"&
				   a_data_[,1]!="5012899"&
				   a_data_[,1]!="5609417"&
				   a_data_[,1]!="5796059"&
				   a_data_[,1]!="1520609"&
				   a_data_[,1]!="1694302"&
				   a_data_[,1]!="2213375"&
				   a_data_[,1]!="2399607"&
				   a_data_[,1]!="3297537"&
				   a_data_[,1]!="4605522"&
				   a_data_[,1]!="4837207"&
				   a_data_[,1]!="5012899"&
				   a_data_[,1]!="5609417"&
				   a_data_[,1]!="5796059")


##Variables
a_data_anl <- na.omit(a_data[a_data[,81]>=0,])
nn <- nrow(a_data_anl)

TT <- a_data_anl[,80]
ZZ <- a_data_anl[,3:79]
YY <- a_data_anl[,81]
ZZ[,c(2,4,9,10,12,13,17,21,24,28,29,33,35,36,38,40,41,42,46,47,49,52,55,56,58,60,61,62,67,69,70,72,73,75,76)] <- abs(ZZ[,c(2,4,9,10,12,13,17,21,24,28,29,33,35,36,38,40,41,42,46,47,49,52,55,56,58,60,61,62,67,69,70,72,73,75,76)]-2)

ZZs <- as.matrix(ZZ)

##NCO (Standardization)
MM <- a_data_anl[,82]-mean(a_data_anl[,82])



##demographics
summary(TT)[c(1,3,4,6)]; sd(TT)
table(a_data_anl[,82]); 100*table(a_data_anl[,82])/nn
table(YY); 100*table(YY)/nn



##Coefficient
coef1 <- coef2 <- coef3 <- matrix(0,ncol=77,nrow=3)
for(ii in 1:77){
  coef1[,ii] <- summary(lm(TT~ZZs[,ii]))[[4]][2,c(1:2,4)]
  coef2[,ii] <- summary(glm(YY~ZZs[,ii]))[[12]][2,c(1:2,4)]
  coef3[,ii] <- summary(glm(a_data_anl[,82]~ZZs[,ii]))[[12]][2,c(1:2,4)]
}

##Effect allele frequency
EAF <- c(100*apply(ZZs,2,sum)/(nn*2))
EAF

##HW test
EAF <- c(apply(ZZs,2,sum)/(nn*2))
OAF <- c(apply(abs(ZZs-2),2,sum)/(nn*2))

EE <- EAF^2*nn
EO <- OAF^2*nn
EH <- 2*EAF*OAF*nn

Xi2 <- (apply(ZZs==2,2,sum)-EE)^2/EE+(apply(ZZs==0,2,sum)-EO)^2/EO+(apply(ZZs==1,2,sum)-EH)^2/EH
HWt <- pchisq(Xi2,1)
HWt


gen_kk <- cbind(paste0(round(coef1[1,],digits=3),"(",round(coef1[2,],digits=3),")"),paste0(coef1[3,]),
		    paste0(round(coef2[1,],digits=3),"(",round(coef2[2,],digits=3),")"),paste0(coef2[3,]),
		    paste0(round(coef3[1,],digits=3),"(",round(coef3[2,],digits=3),")"),paste0(coef3[3,]),
		    paste0(0),paste0(round(100*EAF,digits=2)),paste0(HWt))
#latex(gen_kk,file="C:/Users/81908/Desktop/kk_demo")



