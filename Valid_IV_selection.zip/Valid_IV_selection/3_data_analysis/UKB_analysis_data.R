

library(dplyr)
rm(list = ls(all.names = TRUE))

ukb_geno <- read.csv("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/analysis_data/a_mat_geno2.csv")[,-1]
ukb_diab <- read.csv("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_to_encode/ukb49228_2443.csv")
ukb_ICd <- read.csv("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_to_encode/ukb49228_53.csv")
ukb_BMI <- read.csv("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_to_encode/ukb49228_21001.csv")
ukb_nmsc <- read.csv("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_to_encode/ukb49228_40006.csv")


##�ϐ��̒��o(BMI)
ukb_bmi2 <- data.frame(ukb_BMI[,c(1,2)])
names(ukb_bmi2) <- c("SID","Baseline_BMI")

##�ϐ��̓��o(informed consent)
ukb_ICd2 <- ukb_ICd[(!is.na(ukb_diab[,3])|!is.na(ukb_diab[,4])|!is.na(ukb_diab[,5])),]
ukb_ICd2_ <- ukb_ICd[(is.na(ukb_diab[,3])&is.na(ukb_diab[,4])&is.na(ukb_diab[,5])),]
ukb_ICd3 <- cbind(ukb_ICd2[,1],1)
ukb_ICd3_ <- cbind(ukb_ICd2_[,1],0)
ukb_ICd4 <- data.frame(rbind(ukb_ICd3,ukb_ICd3_))
names(ukb_ICd4) <- c("SID","Follow-up_flag")

a_mat_ <- left_join(ukb_bmi2,ukb_ICd4,by="SID")


##�ϐ��̓��o(diabetes)
ukb_diab_ <- ukb_diab[ukb_diab[,2]==0,]
ukb_diab2 <- cbind(ukb_diab_,apply(is.na(ukb_diab_)[,3:5],1,sum))
ukb_diab3 <- subset(ukb_diab2,ukb_diab2[,6]<=2)

diabetes <- rep(0,nrow(ukb_diab3))
for(ii in 1:nrow(ukb_diab3)){
  if(sum(ukb_diab3[ii,3:5]==1,na.rm=T)>=1) diabetes[ii] <- 1
  else diabetes[ii] <- 0
}

ukb_diab4 <- data.frame(cbind(ukb_diab3[,1],diabetes))
names(ukb_diab4) <- c("SID","Diabetes")

ukb_diab5 <- ukb_diab[,1:2]
names(ukb_diab5) <- c("SID","Baseline_diabetes")

a_mat2_ <- left_join(a_mat_,ukb_diab5,by="SID")
a_mat3_ <- left_join(a_mat2_,ukb_diab4,by="SID")


##�ϐ��̓��o(nco)
nmc_cha2 <- c()
for(ii in 1:nrow(ukb_nmsc)){
  nmc_cha1 <- ukb_nmsc[ii,!is.na(ukb_nmsc[ii,])]
  nmc_cha2 <- c(nmc_cha2,charmatch(c("C44"),nmc_cha1))

  if(ii%%100000==0) print(ii)
}
nmc_cha3 <- replace(nmc_cha2,nmc_cha2>=0,1)
nmc_cha3[is.na(nmc_cha3)] <- 0

ukb_nms2 <- data.frame(cbind(ukb_nmsc[,1],nmc_cha3))
names(ukb_nms2) <- c("SID","Diag_nmsc")



##�f�[�^�Z�b�g�̃}�[�W
a_mat0 <- left_join(ukb_geno,a_mat3_,by="SID")
a_mat <- left_join(a_mat0,ukb_nms2,by="SID")

write.csv(x=a_mat,file="C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/analysis_data/a_mat.csv")


#a_mat <- a_mat[complete.cases(a_mat),]
#nrow(a_mat) ##complete case is "> 99%"



