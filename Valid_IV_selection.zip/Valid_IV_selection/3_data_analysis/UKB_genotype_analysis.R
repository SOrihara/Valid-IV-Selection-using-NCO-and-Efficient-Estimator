

library(bigsnpr)
library(dplyr)
rm(list = ls(all.names = TRUE))


ukb_data1_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c1.rds")$genotypes
ukb_SID1 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_1.sample",header=T)[-1,]
ukb_data1 <- data.frame(cbind(ukb_SID1[,1],as.numeric(ukb_SID1[,4]),ukb_data1_[,1],ukb_data1_[,2],ukb_data1_[,3],ukb_data1_[,4],ukb_data1_[,5],ukb_data1_[,6],ukb_data1_[,7],ukb_data1_[,8],ukb_data1_[,9]))
names(ukb_data1) <- c("SID","Sex","SNP11","SNP12","SNP13","SNP14","SNP15","SNP16","SNP17","SNP18","SNP19")

ukb_data2_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c2.rds")$genotypes
ukb_SID2 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_2.sample",header=T)[-1,]
ukb_data2 <- data.frame(cbind(ukb_SID2[,1],as.numeric(ukb_SID2[,4]),ukb_data2_[,1],ukb_data2_[,2],ukb_data2_[,3],ukb_data2_[,4],ukb_data2_[,5],ukb_data2_[,6],ukb_data2_[,7],ukb_data2_[,8]))
names(ukb_data2) <- c("SID","Sex","SNP21","SNP22","SNP23","SNP24","SNP25","SNP26","SNP27","SNP28")

ukb_data3_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c3.rds")$genotypes
ukb_SID3 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_3.sample",header=T)[-1,]
ukb_data3 <- data.frame(cbind(ukb_SID3[,1],as.numeric(ukb_SID3[,4]),ukb_data3_[,1],ukb_data3_[,2],ukb_data3_[,3],ukb_data3_[,4],ukb_data3_[,5],ukb_data3_[,6]))
names(ukb_data3) <- c("SID","Sex","SNP31","SNP32","SNP33","SNP34","SNP35","SNP36")

ukb_data4_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c4.rds")$genotype
ukb_SID4 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_4.sample",header=T)[-1,]
ukb_data4 <- data.frame(cbind(ukb_SID4[,1],as.numeric(ukb_SID4[,4]),ukb_data4_[,1],ukb_data4_[,2],ukb_data4_[,3],ukb_data4_[,4]))
names(ukb_data4) <- c("SID","Sex","SNP41","SNP42","SNP43","SNP44")

#ukb_data5_ <- readRDS("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c5.rds")$genotype
#ukb_SID5 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_5.sample",header=T)[-1,]
#ukb_data5 <- data.frame(cbind(ukb_SID5[,1],as.numeric(ukb_SID5[,4]),ukb_data5_[,1]))
#names(ukb_data5) <- c("SID","Sex","SNP51")

ukb_data6_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c6.rds")$genotypes
ukb_SID6 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_6.sample",header=T)[-1,]
ukb_data6 <- data.frame(cbind(ukb_SID6[,1],as.numeric(ukb_SID6[,4]),ukb_data6_[,1],ukb_data6_[,2],ukb_data6_[,3],ukb_data6_[,4],ukb_data6_[,5]))
names(ukb_data6) <- c("SID","Sex","SNP61","SNP62","SNP63","SNP64","SNP65")

#ukb_data7_ <- readRDS("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c7.rds")$genotype
#ukb_SID7 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_7.sample",header=T)[-1,]
#ukb_data7 <- data.frame(cbind(ukb_SID7[,1],as.numeric(ukb_SID7[,4]),ukb_data7_[,1],ukb_data7_[,2]))
#names(ukb_data7) <- c("SID","Sex","SNP71","SNP72")

ukb_data8_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c8.rds")$genotype
ukb_SID8 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_8.sample",header=T)[-1,]
ukb_data8 <- data.frame(cbind(ukb_SID8[,1],as.numeric(ukb_SID8[,4]),ukb_data8_[,1],ukb_data8_[,2]))
names(ukb_data8) <- c("SID","Sex","SNP81","SNP82")

ukb_data9_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c9.rds")$genotype
ukb_SID9 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_9.sample",header=T)[-1,]
ukb_data9 <- data.frame(cbind(ukb_SID9[,1],as.numeric(ukb_SID9[,4]),ukb_data9_[,1],ukb_data9_[,2],ukb_data9_[,3],ukb_data9_[,4],ukb_data9_[,5]))
names(ukb_data9) <- c("SID","Sex","SNP91","SNP92","SNP93","SNP94","SNP95")

ukb_data10_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c10.rds")$genotype
ukb_SID10 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_10.sample",header=T)[-1,]
ukb_data10 <- data.frame(cbind(ukb_SID10[,1],as.numeric(ukb_SID10[,4]),ukb_data10_[,1],ukb_data10_[,2],ukb_data10_[,3],ukb_data10_[,4]))
names(ukb_data10) <- c("SID","Sex","SNP101","SNP102","SNP103","SNP104")

ukb_data11_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c11.rds")$genotype
ukb_SID11 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_11.sample",header=T)[-1,]
ukb_data11 <- data.frame(cbind(ukb_SID11[,1],as.numeric(ukb_SID11[,4]),ukb_data11_[,1],ukb_data11_[,2],ukb_data11_[,3],ukb_data11_[,4],ukb_data11_[,5]))
names(ukb_data11) <- c("SID","Sex","SNP111","SNP112","SNP113","SNP114","SNP115")

#ukb_data12_ <- readRDS("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c12.rds")$genotype
#ukb_SID12 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_12.sample",header=T)[-1,]
#ukb_data12 <- data.frame(cbind(ukb_SID12[,1],as.numeric(ukb_SID12[,4]),ukb_data12_[,1],ukb_data12_[,2]))
#names(ukb_data12) <- c("SID","Sex","SNP121","SNP122")

ukb_data13_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c13.rds")$genotype
ukb_SID13 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_13.sample",header=T)[-1,]
ukb_data13 <- data.frame(cbind(ukb_SID13[,1],as.numeric(ukb_SID13[,4]),ukb_data13_[,1],ukb_data13_[,2]))
names(ukb_data13) <- c("SID","Sex","SNP131","SNP132")

ukb_data14_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c14.rds")$genotype
ukb_SID14 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_14.sample",header=T)[-1,]
ukb_data14 <- data.frame(cbind(ukb_SID14[,1],as.numeric(ukb_SID14[,4]),ukb_data14_[,1],ukb_data14_[,2],ukb_data14_[,3],ukb_data14_[,4]))
names(ukb_data14) <- c("SID","Sex","SNP141","SNP142","SNP143","SNP144")

ukb_data15_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c15.rds")$genotype
ukb_SID15 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_15.sample",header=T)[-1,]
ukb_data15 <- data.frame(cbind(ukb_SID15[,1],as.numeric(ukb_SID15[,4]),ukb_data15_[,1],ukb_data15_[,2]))
names(ukb_data15) <- c("SID","Sex","SNP151","SNP152")

ukb_data16_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c16.rds")$genotype
ukb_SID16 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_16.sample",header=T)[-1,]
ukb_data16 <- data.frame(cbind(ukb_SID16[,1],as.numeric(ukb_SID16[,4]),ukb_data16_[,1],ukb_data16_[,2],ukb_data16_[,3],ukb_data16_[,4],ukb_data16_[,5],ukb_data16_[,6]))
names(ukb_data16) <- c("SID","Sex","SNP161","SNP162","SNP163","SNP164","SNP165","SNP166")

ukb_data17_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c17.rds")$genotype
ukb_SID17 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_17.sample",header=T)[-1,]
ukb_data17 <- data.frame(cbind(ukb_SID17[,1],as.numeric(ukb_SID17[,4]),ukb_data17_[,1],ukb_data17_[,2]))
names(ukb_data17) <- c("SID","Sex","SNP171","SNP172")

ukb_data18_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c18.rds")$genotype
ukb_SID18 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_18.sample",header=T)[-1,]
ukb_data18 <- data.frame(cbind(ukb_SID18[,1],as.numeric(ukb_SID18[,4]),ukb_data18_[,1],ukb_data18_[,2],ukb_data18_[,3]))
names(ukb_data18) <- c("SID","Sex","SNP181","SNP182","SNP183")

ukb_data19_ <- snp_attach("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c19.rds")$genotype
ukb_SID19 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_19.sample",header=T)[-1,]
ukb_data19 <- data.frame(cbind(ukb_SID19[,1],as.numeric(ukb_SID19[,4]),ukb_data19_[,1],ukb_data19_[,2],ukb_data19_[,3],ukb_data19_[,4],ukb_data19_[,5]))
names(ukb_data19) <- c("SID","Sex","SNP191","SNP192","SNP193","SNP194","SNP195")

#ukb_data20_ <- readRDS("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c20.rds")$genotype
#ukb_SID20 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_20.sample",header=T)[-1,]
#ukb_data20 <- data.frame(cbind(ukb_SID20[,1],as.numeric(ukb_SID20[,4]),ukb_data20_[,1]))
#names(ukb_data20) <- c("SID","Sex","SNP201")

#ukb_data21_ <- readRDS("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/extract_c21.rds")$genotype
#ukb_SID21 <- read.table("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/_gfetch/SID_21.sample",header=T)[-1,]
#ukb_data21 <- data.frame(cbind(ukb_SID21[,1],as.numeric(ukb_SID21[,4]),ukb_data21_[,1]))
#names(ukb_data21) <- c("SID","Sex","SNP211")



a_mat11 <- left_join(ukb_data1,ukb_data2[,-2],by="SID")
a_mat12 <- left_join(ukb_data3[,-2],ukb_data4[,-2],by="SID")
a_mat13 <- left_join(ukb_data6[,-2],ukb_data8[,-2],by="SID")
a_mat14 <- left_join(ukb_data9[,-2],ukb_data10[,-2],by="SID")
a_mat15 <- left_join(ukb_data11[,-2],ukb_data13[,-2],by="SID")
a_mat16 <- left_join(ukb_data14[,-2],ukb_data15[,-2],by="SID")
a_mat17 <- left_join(ukb_data16[,-2],ukb_data17[,-2],by="SID")
a_mat18 <- left_join(ukb_data18[,-2],ukb_data19[,-2],by="SID")

a_mat1 <- left_join(a_mat11,a_mat12,by="SID")
a_mat2 <- left_join(a_mat13,a_mat14,by="SID")
a_mat3 <- left_join(a_mat15,a_mat16,by="SID")
a_mat4 <- left_join(a_mat17,a_mat18,by="SID")

a_mat1_ <- left_join(a_mat1,a_mat2,by="SID")
a_mat2_ <- left_join(a_mat3,a_mat4,by="SID")

a_mat_geno <- left_join(a_mat1_,a_mat2_,by="SID")


##Merge with old dataset
a_mat_geno_ <- read.csv("C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/analysis_data/a_mat_geno.csv")

SNP51 <- a_mat_geno_$SNP51
SNP71 <- a_mat_geno_$SNP71
SNP72 <- a_mat_geno_$SNP72
SNP121 <- a_mat_geno_$SNP121
SNP122 <- a_mat_geno_$SNP122

a_mat_geno_2 <- cbind(a_mat_geno[,1:29],SNP51,a_mat_geno[,30:34],SNP71,SNP72,
			    a_mat_geno[,35:50],SNP121,SNP122,a_mat_geno[,51:ncol(a_mat_geno)])

write.csv(x=a_mat_geno_2,file="C:/Users/Taguri/Desktop/D1_Orihara/4_UK_Biobank/analysis_data/a_mat_geno2.csv")






