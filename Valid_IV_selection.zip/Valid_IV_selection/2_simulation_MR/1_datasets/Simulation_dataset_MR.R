

rm(list = ls(all.names = TRUE))
set.seed(20220331)

library(MASS)
#library(sisVIVE)
#library(nleqslv)

#source("C:/Users/Taguri/Desktop/Orihara/D1_Orihara/GMM_NCO_loglin.R")



nn <- 20000

#Parameters
##The settings are greatly referenced by Gkatzionis, 2021
PP <- 100
ff <- runif(PP,0.1,0.9)
aa <- rnorm(PP,0.4,0.2)
bb <- 0.5+abs(rnorm(PP,0,0.5))

#par(mfcol=c(1,2))
#plot(0.4*aa); plot(0.2*bb)

aa[1:70] <- 0
#aa[1:30] <- 0



for(kk in 1:1000){

##Instrumental variables
GG <- matrix(0,ncol=PP,nrow=nn)
for(ii in 1:nn){
  GG[ii,] <- rbinom(PP,2,ff)
}


##Unmeasured confounder
UU <- 0.4*t(t(GG)-2*ff)%*%aa+rnorm(nn,0,1)


##Exposure
TT <- 0.2*GG%*%bb+UU

#hist(TT); sd(TT); sd(UU); sd(0.2*GG%*%bb)
#mean(TT) = 18.5   ##Majority
#mean(TT) = 17.7   ##Minority


##Outcome
###Continuous outcome
YY_c <- -2+0.3*TT+UU

#hist(YY_c); mean(YY_c); sd(YY_c)


###Binary outcome
YY_lin <- -2+0.15*(TT-18.5)+UU/5
YY_lin[YY_lin>=0] <- 0
ee <- exp(YY_lin)
YY_b <- mapply(rbinom,1,1,ee)

#hist(YY_lin); 100*mean(YY_b)


##NCO
MM_1 <- 1+1*UU+rnorm(nn,sd=1)
MM_2 <- 1+0.35*UU+rnorm(nn,sd=1)

#MM_1 <- 1+0.8*UU+rnorm(nn,sd=1)
#MM_2 <- 1+0.3*UU+rnorm(nn,sd=1)


#cor(UU,MM_1); cor(UU,MM_2)
#par(mfcol=c(1,2))
#plot(t(cor(MM_1,GG))); plot(t(cor(MM_2,GG)))


#cv.sisVIVE(YY_b,TT,GG)

#gamma <- NCO_func(0.5,as.matrix(GG),MM_2-mean(MM_2),TT)
#plot(gamma)
#GMM_func(gamma,GG,TT,YY_b)[[1]]


#Previous methods
#kkyy <- kkxx <- matrix(0,nrow=2,ncol=100)
#for(ll in 1:100){
#  kkxx[,ll] <- summary(lm(TT~GG[,ll]))[[4]][2,1:2]
#  kkyy[,ll] <- summary(lm(YY_c~GG[,ll]))[[4]][2,1:2]
#}
#beta_IV <- kkyy[1,]/kkxx[1,]

##Mod-est.
###Estimate of the weights proposed by Hartwig et al., 2017
#sigma_R <- sqrt(kkyy[2,]^2/kkxx[1,]^2+kkyy[1,]^2*kkxx[2,]^2/kkxx[1,]^4)
#ww_mod <- sigma_R^(-2)/sum(sigma_R^(-2))

###Mode estimate
#hh <- 0.9*min(sd(beta_IV),1.4826*median(beta_IV))/100^(1/5)
#mod_func <- function(xx){
#  return(-1/(hh*sqrt(2*pi))*sum(ww_mod*exp(-0.5*((xx-beta_IV)/hh)^2)))
#}
#optimize(mod_func,interval=c(-2,2))$min


#Sample ID
ID <- 1:nn

inst_data <- cbind(ID,TT,GG,YY_c,YY_b,MM_1,MM_2,kk)

if(kk==1) inst_data2 <- inst_data
else inst_data2 <- rbind(inst_data2,inst_data)

if(kk%%10==0) print(kk)
}


write.csv(inst_data2,"C:/Users/Taguri/Desktop/Orihara/D1_Orihara/Inst_data_MR",row.names=F)
#write.csv(inst_data2,"~/Desktop/4_UK_Biobank/Inst_data_MR2",row.names=F)


