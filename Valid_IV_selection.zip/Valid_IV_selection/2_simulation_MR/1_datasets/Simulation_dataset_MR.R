

library(MASS)
rm(list = ls(all.names = TRUE))

nn <- 10000
set.seed(20220331)

#Parameters
##The settings are referenced by Gkatzionis, 2021
sigma <- 0.1

PP <- 100
ff <- runif(PP,0.1,0.9)
aa <- rnorm(PP,0.4,0.1)
bb <- 0.5+abs(rnorm(PP,0,0.5))

#aa[1:70] <- 0
aa[1:30] <- 0


for(kk in 1:1000){
GG <- matrix(0,ncol=PP,nrow=nn)
for(ii in 1:nn){
  GG[ii,] <- rbinom(PP,2,ff)
}

UU <- t(t(GG)-2*ff)%*%aa+rnorm(nn,0,sigma)

TT <- GG%*%bb+UU 


YY <- 1+0.3*TT+UU
#MM <- 1+0.8*UU+rnorm(nn,sd=1)
MM <- 1+0.5*UU+rnorm(nn,sd=1)

#cor(UU,GG)
cor(UU,MM)
#cor(GG,MM)

#plot(c(cor(MM,GG)))
#plot(c(cor(UU,GG)))

#Sample ID
ID <- 1:nn

inst_data <- cbind(ID,TT,GG,YY,MM,kk)

if(kk==1) inst_data2 <- inst_data
else inst_data2 <- rbind(inst_data2,inst_data)

if(kk%%10==0) print(kk)
}

write.csv(inst_data2,"~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_MR2",row.names=F)
#write.csv(inst_data2,"~/Desktop/4_UK_Biobank/Inst_data_MR2",row.names=F)


