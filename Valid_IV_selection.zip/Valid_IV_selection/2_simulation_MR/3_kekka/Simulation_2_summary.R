

data1 <- read.csv("C:/Users/81908/Desktop/OneDrive_2_2022-7-15/kekka_MR")
data2 <- read.csv("C:/Users/81908/Desktop/OneDrive_2_2022-7-15/kekka_MR2")

data_ <- data.frame(t(rbind(data1,data2)))
data <- cbind(data_[,5],data_[,1:4],data_[,10],data_[,6:9])

names(data) <- c("Proposed\nvalid IVs\nare major","IVM\nvalid IVs\nare major","MR-Egger\nvalid IVs\nare major","Median\nvalid IVs\nare major","Mode\nvalid IVs\nare major",
                 "Proposed\nvalid IVs\nare minor","IVM\nvalid IVs\nare minor","MR-Egger\nvalid IVs\nare minor","Median\nvalid IVs\nare minor","Mode\nvalid IVs\nare minor")


apply(data,2,mean)
apply(data,2,sd)
apply(data,2,summary)
apply(data,2,mean)-0.3
sqrt(apply(data,2,var)+(apply(data,2,mean)-0.3)^2)



pdf("C:/Users/81908/Desktop/OneDrive_2_2022-7-15/zu1.pdf",width=14,height=10)
par(mgp=c(3,3,0))
boxplot(data,locations=c(-5,0),yaxt="n",ylab="Coefficient estimates of beta_t",ylim=c(0.3,0.9))
par(mgp=c(1,1,0))
axis(side=2)
abline(v=5.5,lty=2)
abline(h=0.3,lwd=2,col="red")
dev.off()

