

library(Hmisc)

data1 <- cbind(t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_CO_SN")),
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_CO_WN"))[,5]
              )
data2 <- cbind(t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MN_CO_SN")),
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MN_CO_WN"))[,5]
)

data3 <- cbind(t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_BO_SN"))[,1],
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_BO_WN"))[,1]
)
data4 <- cbind(t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MN_BO_SN"))[,1],
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MN_BO_WN"))[,1]
)


sum_func <- function(dta1,dta2){
  kk1 <- data.frame(P1 = paste0(round(mean(dta1[,1]),digits=3)," (",round(sd(dta1[,1]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,1]),digits=3)," (",round(min(dta1[,1]),digits=2),", ",round(max(dta1[,1]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,1])-0.3,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,1])+(mean(dta1[,1])-0.3)^2),digits=3))
				    )
  kk2 <- data.frame(P1 = paste0(round(mean(dta1[,2]),digits=3)," (",round(sd(dta1[,2]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,2]),digits=3)," (",round(min(dta1[,2]),digits=2),", ",round(max(dta1[,2]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,2])-0.3,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,2])+(mean(dta1[,2])-0.3)^2),digits=3))
				    )
  kk3 <- data.frame(P1 = paste0(round(mean(dta1[,3]),digits=3)," (",round(sd(dta1[,3]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,3]),digits=3)," (",round(min(dta1[,3]),digits=2),", ",round(max(dta1[,3]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,3])-0.3,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,3])+(mean(dta1[,3])-0.3)^2),digits=3))
				    )
  kk4 <- data.frame(P1 = paste0(round(mean(dta1[,4]),digits=3)," (",round(sd(dta1[,4]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,4]),digits=3)," (",round(min(dta1[,4]),digits=2),", ",round(max(dta1[,4]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,4])-0.3,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,4])+(mean(dta1[,4])-0.3)^2),digits=3))
				    )
  kk5 <- data.frame(P1 = paste0(round(mean(dta1[,5]),digits=3)," (",round(sd(dta1[,5]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,5]),digits=3)," (",round(min(dta1[,5]),digits=2),", ",round(max(dta1[,5]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,5])-0.3,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,5])+(mean(dta1[,5])-0.3)^2),digits=3))
				    )
  kk6 <- data.frame(P1 = paste0(round(mean(dta1[,6]),digits=3)," (",round(sd(dta1[,6]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,6]),digits=3)," (",round(min(dta1[,6]),digits=2),", ",round(max(dta1[,6]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,6])-0.3,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,6])+(mean(dta1[,6])-0.3)^2),digits=3))
				    )
  kk7 <- data.frame(P1 = paste0(round(mean(dta1[,7]),digits=3)," (",round(sd(dta1[,7]),digits=3),")"),
                    P2 = paste0(round(median(dta1[,7]),digits=3)," (",round(min(dta1[,7]),digits=2),", ",round(max(dta1[,7]),digits=2),")"),
                    P3 = paste0(round(mean(dta1[,7])-0.3,digits=3)),
                    P4 = paste0(round(sqrt(var(dta1[,7])+(mean(dta1[,7])-0.3)^2),digits=3))
  )
  return(rbind(kk1,kk2,kk3,kk4,kk5,kk6,kk7))
}


latex(sum_func(data1),file="C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kk_sum_MJ")
latex(sum_func(data2),file="C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kk_sum_MN")


sum_func2 <- function(dta1,dta2){
  kk1 <- data.frame(P1 = paste0(round(mean(dta1[,1]),digits=3)," (",round(sd(dta1[,1]),digits=3),")"),
                    P2 = paste0(round(median(dta1[,1]),digits=3)," (",round(min(dta1[,1]),digits=2),", ",round(max(dta1[,1]),digits=2),")"),
                    P3 = paste0(round(mean(dta1[,1])-0.15,digits=3)),
                    P4 = paste0(round(sqrt(var(dta1[,1])+(mean(dta1[,1])-0.15)^2),digits=3))
  )
  kk2 <- data.frame(P1 = paste0(round(mean(dta1[,2]),digits=3)," (",round(sd(dta1[,2]),digits=3),")"),
                    P2 = paste0(round(median(dta1[,2]),digits=3)," (",round(min(dta1[,2]),digits=2),", ",round(max(dta1[,2]),digits=2),")"),
                    P3 = paste0(round(mean(dta1[,2])-0.15,digits=3)),
                    P4 = paste0(round(sqrt(var(dta1[,2])+(mean(dta1[,2])-0.15)^2),digits=3))
  )
  return(rbind(kk1,kk2))
}

latex(sum_func2(data3),file="C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kk_sum_MJ_BO")
latex(sum_func2(data4),file="C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kk_sum_MN_BO")







