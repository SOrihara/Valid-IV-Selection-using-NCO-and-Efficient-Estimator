

data1 <- data.frame(cbind(t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_CO_SN"))[,5],
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_CO_WN"))[,5],
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_CO_SN"))[,c(1,3,4,6)]
))
data2 <- data.frame(cbind(t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MN_CO_SN"))[,5],
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MN_CO_WN"))[,5],
               t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MN_CO_SN"))[,c(1,3,4,6)]
))

names(data1) <- names(data2) <- c("Proposed\nStrong NCO","Proposed\nWeak NCO","IVM","Median-based","Mode-based","sisVIVE")


pdf("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/zu1.pdf",width=14,height=10)
par(mfrow=c(2,1))
par(mgp=c(3,2,0))
boxplot(data1,locations=c(-5,0),yaxt="n",ylab="Estimates of the causal effect",ylim=c(0.25,0.9))
par(mgp=c(1,1,0))
axis(side=2)
abline(h=0.3,lwd=3,col="red",lty=2)
legend("topleft",legend=c("Valid IVs are in Majority"),cex=0.8,bg = "white")
par(mgp=c(3,2,0))
boxplot(data2,locations=c(-5,0),yaxt="n",ylab="Estimates of the causal effect",ylim=c(0.25,0.9))
par(mgp=c(1,1,0))
axis(side=2)
abline(h=0.3,lwd=3,col="red",lty=2)
legend("topleft",legend=c("Valid IVs are in Minority"),cex=0.8,bg = "white")
dev.off()

