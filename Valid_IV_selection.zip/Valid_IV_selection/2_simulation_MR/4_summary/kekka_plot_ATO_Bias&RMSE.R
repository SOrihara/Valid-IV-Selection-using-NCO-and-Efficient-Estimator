

library(ggplot2)

data1 <- cbind(t(read.csv("C:/Users/81908/Desktop/OneDrive_1_2023-1-27/kekka_MR_MJ_CO_SN_SA"))
)

BB1 <- abs(round(apply(data1,2,mean)-0.3,digits=3)); RMSE1 <- round(sqrt(apply(data1,2,var)+BB1^2),digits=3)

x <- c()
for (i in 1:5) {
  x <- append(x, rep(i, 6))
}
y <- rep(1:6,5)
seq <- cbind(x,y)


kk_t <- data.frame(cbind(seq,BB1,RMSE1))
names(kk_t) <- c("label_y","label_x","Bias","RMSE")


#pdf("C:/Users/81908/Desktop/MR_PS simulation/_kekka/kk_ATO_Bias.pdf",width=7,height=10)
ggplot() +
  scale_fill_gradient(low = "white", high = "red", name = "scale") +
  geom_tile(data=kk_t,aes(y=x,x=y,fill=Bias)) +
  geom_text(data=kk_t,aes(y=x,x=y,label=round(Bias,3)), size=5)
  #scale_x_discrete(limits=c("n=800","n=1200","n=1600"))
  #labs(title="Absolute value of Bias",x="Sample size",y="Methods")
#dev.off()


#pdf("C:/Users/81908/Desktop/MR_PS simulation/_kekka/kk_ATO_RMSE.pdf",width=7,height=10)
ggplot() +
  scale_fill_gradient(low = "white", high = "green", name = "scale") +
  geom_tile(data=kk_t,aes(y=x,x=y,fill=RMSE)) +
  geom_text(data=kk_t,aes(y=x,x=y,label=round(RMSE,3)), size=5)
#dev.off()




