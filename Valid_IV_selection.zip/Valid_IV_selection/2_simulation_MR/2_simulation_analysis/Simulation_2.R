

rm(list = ls(all.names = TRUE))
#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_MR")
#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_MR2")

#data1 <- read.csv("~/Desktop/4_UK_Biobank/Inst_data_MR")
#data1 <- read.csv("~/Desktop/4_UK_Biobank/Inst_data_MR2")

library(nleqslv)

source("~/Desktop/D_Orihara/Simulation_IVselect/GMM_NCO.R")
#source("~/Desktop/4_UK_Biobank/GMM_NCO_simu1.R")


nn <- 10000
KK <- 1000

est <- matrix(0,ncol=KK,nrow=5)


for(mm in 1:KK){
data_anl <- subset(data1,data1[,1]<=nn&data1[,105]==mm)

#Variables
TT <- data_anl[,2]
ZZ <- data_anl[,3:102]
YY <- data_anl[,103]

#NCO (Standardization)
MM <- data_anl[,104]-mean(data_anl[,104])


#Previous methods
kkyy <- kkxx <- matrix(0,nrow=2,ncol=100)
for(ll in 1:100){
  kkxx[,ll] <- summary(lm(TT~ZZ[,ll]))[[4]][2,1:2]
  kkyy[,ll] <- summary(lm(YY~ZZ[,ll]))[[4]][2,1:2]
}

beta_IV <- kkyy[1,]/kkxx[1,]

##IVM
beta_IVM <- sum(beta_IV*kkxx[1,]^2/kkyy[2,]^2)/sum(kkxx[1,]^2/kkyy[2,]^2)


##Egger-reg.
beta_EGG <- summary(lm(kkyy[1,]~kkxx[1,]))[[4]][2,1]


##Med-est.
###Estimate of the weights proposed by Bowden et al., 2016
ww_med_ <- kkxx[1,]^2/kkyy[2,]^2
med_vec <- cbind(beta_IV,ww_med_)
med_vec <- med_vec[order(med_vec[,1]),]
ww_med <- med_vec[,2]/sum(med_vec[,2])

###Estimate of the percentiles
ss_med <- cumsum(ww_med)
pp_med <- 100*(ss_med-ww_med/2)
med_vec2 <- cbind(med_vec,pp_med)

###Mediation estimate
med_vec_LL <- med_vec2[med_vec2[,3]<50,]
med_vec_UU <- med_vec2[med_vec2[,3]>=50,]
beta_MED <- (med_vec_UU[1,1]+med_vec_LL[nrow(med_vec_LL),1])/2


##Mod-est.
###Estimate of the weights proposed by Hartwig et al., 2017
sigma_R <- sqrt(kkyy[2,]^2/kkxx[1,]^2+kkyy[1,]^2*kkxx[2,]^2/kkxx[1,]^4)
ww_mod <- sigma_R^(-2)/sum(sigma_R^(-2))

###Mode estimate
hh <- 0.9*min(sd(beta_IV),1.4826*median(beta_IV))/100^(1/5)
mod_func <- function(xx){
  return(-1/(hh*sqrt(2*pi))*sum(ww_mod*exp(-0.5*((xx-beta_IV)/hh)^2)))
}
beta_MOD <- optimize(mod_func,interval=c(-2,2))$min


##LASSO
#Min_func <- function(beta){
#  theta1 <- beta[1:50]; theta2 <- beta[51]
#  LF <- sum((kkyy[1,]-theta1-theta2*kkxx[1,])^2/kkyy[2,]^2)+0.5*sum(abs(theta1))
#  return(LF)
#}
#optim(c(rep(1,50),0),Min_func)


#Proposed method
TT_1 <- cbind(1,TT)

gamma <- NCO_func(0.1,as.matrix(ZZ),MM,TT)
beta_OT <- GMM_func(gamma,as.matrix(ZZ),TT,YY)[[1]]

c(beta_IVM,beta_EGG,beta_MED,beta_MOD,beta_OT[2])



##Summarize all methods
est[,mm]=c(beta_IVM,beta_EGG,beta_MED,beta_MOD,beta_OT[2])

if(mm%%100==0) print(mm)
}

apply(est,1,mean); apply(est,1,sd)
apply(est,1,quantile)
sqrt(apply(est,1,var)+(apply(est,1,mean)-0.3)^2)

kk <- list(est[1,],est[2,],est[3,],est[4,],est[5,])
#names(kk) <- c("GMM (ordinary)","Liao, 2013","DiTraglia, 2016","Proposed")

#par(mfcol=c(1,3))
#hist(kk[[1]]); hist(kk[[2]]); hist(kk[[3]])

#write.csv(est,"~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_MR2",row.names=F)

boxplot(kk)



rm(list = ls(all.names = TRUE))
data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_MR")
#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_MR2")

nn=100000

source("~/Desktop/D_Orihara/Simulation_IVselect/GMM_NCO.R")
data_anl <- subset(data1,data1[,1]<=nn&data1[,105]==1)
ZZ <- data_anl[,3:102]
MM <- data_anl[,104]-mean(data_anl[,104])
pdf("~/Desktop/D_Orihara/Simulation_IVselect/kekka/zu5.pdf",width=16,height=10)
Choice_func(0.1,ZZ,MM)
dev.off()





