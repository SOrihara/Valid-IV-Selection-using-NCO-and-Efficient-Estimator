

#rm(list = ls(all.names = TRUE))

library(MASS)
library(nleqslv)
#library(sisVIVE)
#library(controlfunctionIV)

#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_MR")
#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_MR2")

#data1 <- read.csv("~/Desktop/4_UK_Biobank/Inst_data_MR")
#data1 <- read.csv("~/Desktop/4_UK_Biobank/Inst_data_MR2")

#data1 <- read.csv("C:/Users/81908/Desktop/IV_selection_simu/2_simulation_MR/1_datasets/Inst_data_MR2")
#data1 <- read.csv("C:/Users/Taguri/Desktop/Orihara/D1_Orihara/Inst_data_MR")


source("C:/Users/Taguri/Desktop/Orihara/D1_Orihara/GMM_NCO_lin.R")
#source("C:/Users/Taguri/Desktop/Orihara/D1_Orihara/GMM_NCO_loglin.R")
#source("C:/Users/81908/Desktop/IV_selection_simu/GMM_NCO_lin.R")
#source("~/Desktop/4_UK_Biobank/GMM_NCO_simu1.R")


nn <- 10000
KK <- 1000

est <- matrix(0,ncol=KK,nrow=20)
beta_OT <- matrix(0,ncol=5,nrow=4)

for(mm in 1:KK){
data_anl <- subset(data1,data1[,1]<=nn&data1[,107]==mm)

#Variables
TT <- data_anl[,2]
ZZ <- data_anl[,3:102]
YY <- data_anl[,103]
#YY <- data_anl[,104]

#NCO (Standardization)
MM <- data_anl[,105]-mean(data_anl[,105])
#MM <- data_anl[,106]-mean(data_anl[,106])


#Proposed method

tau_g <- c(1e-6,1e-4,1e-2,1)
kappa1_g <- c(1,1e2,1e4,1e6,1e8)

for(ii in 1:4){
  for(jj in 1:5){
    gamma <- NCO_func(0.5,as.matrix(ZZ),MM,TT,tau_g[ii],kappa1_g[jj])
    beta_OT[ii,jj] <- GMM_func(gamma,as.matrix(ZZ),TT,YY)[[1]][2]
  }
}

##Summarize all methods
est[,mm]=c(beta_OT)

if(mm%%10==0) print(mm)
}

apply(est,1,mean); apply(est,1,sd)
apply(est,1,quantile)
sqrt(apply(est,1,var)+(apply(est,1,mean)-0.3)^2)

boxplot(t(est))

write.csv(est,"C:/Users/Taguri/Desktop/Orihara/D1_Orihara/kekka_MR_MJ_CO_SN_SA",row.names=F)








