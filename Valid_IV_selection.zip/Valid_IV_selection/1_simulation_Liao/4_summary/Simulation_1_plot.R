

data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_11")
data2 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_12")
data3 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_21")
data4 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_22")
data5 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_11")
data6 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_12")
data7 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_21")
data8 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_22")
data9 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n500_1")
data10 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n500_2")
data11 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n1000_1")
data12 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n1000_2")


data_siv_500 <- data.frame(t(rbind(data1[4,],data3[4,],data1[2,],data1[3,],data1[1,],data9[2,],data9[3,],data9[1,])))
data_siv_2000 <- data.frame(t(rbind(data5[4,],data7[4,],data5[2,],data5[3,],data5[1,],data11[2,],data11[3,],data11[1,])))
data_wiv_500 <- data.frame(t(rbind(data2[4,],data4[4,],data2[2,],data2[3,],data2[1,],data10[2,],data10[3,],data10[1,])))
data_wiv_2000 <- data.frame(t(rbind(data6[4,],data8[4,],data6[2,],data6[3,],data6[1,],data12[2,],data12[3,],data12[1,])))


names(data_siv_500) <- names(data_siv_2000) <- names(data_wiv_500) <- names(data_wiv_2000) <- c("Proposed\n(strong NCO)","Proposed\n(weak NCO)","Liao, 2013\n(specify)","DiTraglia, 2016\n(specify)","GMM\n(specify)","Liao, 2013\n(unspecify)","DiTraglia, 2016\n(unspecify)","GMM\n(unspecify)")

kk1 <- list(data_siv_500,data_siv_2000,data_wiv_500,data_wiv_2000)
names(kk1) <- c("Strong IV, n=500","Strong IV, n=1000","Weak IV, n=500","Weak IV, n=1000")



pdf("~/Desktop/D_Orihara/Simulation_IVselect/kekka/zu1.pdf",width=14,height=10)
par(mgp=c(3,2,0))
boxplot(kk1[[1]],ylim=c(0,2),ylab="Coefficient estimates of beta_t",locations=c(-5,0),yaxt="n"); abline(h=0.8,col="red")
par(mgp=c(1,1,0))
axis(side=2,at=seq(0,2,by=0.2))
labels <- names(kk1[1])
legend("topleft",legend=labels,cex=0.8)
dev.off()

pdf("~/Desktop/D_Orihara/Simulation_IVselect/kekka/zu2.pdf",width=14,height=10)
par(mgp=c(3,2,0))
boxplot(kk1[[2]],ylim=c(0,2),ylab="Coefficient estimates of beta_t",locations=c(-5,0),yaxt="n"); abline(h=0.8,col="red")
par(mgp=c(1,1,0))
axis(side=2,at=seq(0,2,by=0.2))
labels <- names(kk1[2])
legend("topleft",legend=labels,cex=0.8)
dev.off()

pdf("~/Desktop/D_Orihara/Simulation_IVselect/kekka/zu3.pdf",width=14,height=10)
par(mgp=c(3,2,0))
boxplot(kk1[[3]],ylim=c(0,4),ylab="Coefficient estimates of beta_t",locations=c(-5,0),yaxt="n"); abline(h=0.8,col="red")
par(mgp=c(1,1,0))
axis(side=2,at=seq(0,4,by=0.2))
labels <- names(kk1[3])
legend("topleft",legend=labels,cex=0.8)
dev.off()

pdf("~/Desktop/D_Orihara/Simulation_IVselect/kekka/zu4.pdf",width=14,height=10)
par(mgp=c(3,2,0))
boxplot(kk1[[4]],ylim=c(0,4),ylab="Coefficient estimates of beta_t",locations=c(-5,0),yaxt="n"); abline(h=0.8,col="red")
par(mgp=c(1,1,0))
axis(side=2,at=seq(0,4,by=0.2))
labels <- names(kk1[4])
legend("topleft",legend=labels,cex=0.8)
dev.off()



