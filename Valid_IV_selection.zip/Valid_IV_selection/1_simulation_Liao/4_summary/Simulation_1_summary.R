

library(Hmisc)

data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_11")
data2 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_12")
data3 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_21")
data4 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n500_22")
data5 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_11")
data6 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_12")
data7 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_21")
data8 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_specify_n1000_22")
data9 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n500_1")
data10 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n500_2")
data11 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n1000_1")
data12 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n1000_2")


data_siv_500 <- data.frame(t(rbind(data1,data3[4,],data9)))
data_siv_2000 <- data.frame(t(rbind(data5,data7[4,],data11)))
data_wiv_500 <- data.frame(t(rbind(data2,data4[4,],data10)))
data_wiv_2000 <- data.frame(t(rbind(data6,data8[4,],data12)))

names(data_siv_500) <- names(data_siv_2000) <- names(data_wiv_500) <- names(data_wiv_2000) <- c("GMM\n(specify)","Liao, 2013\n(specify)","DiTraglia, 2016\n(specify)","Proposed\n(strong NCO)","OLS","Proposed\n(weak NCO)","GMM\n(unspecify)","Liao, 2013\n(unspecify)","DiTraglia, 2016\n(unspecify)")


sum_func <- function(dta1,dta2){
  kk1 <- data.frame(P1 = paste0(round(mean(dta1[,1]),digits=3)," (",round(sd(dta1[,1]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,1]),digits=3)," (",round(min(dta1[,1]),digits=2),", ",round(max(dta1[,1]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,1])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,1])+(mean(dta1[,1])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,1]),digits=3)," (",round(sd(dta2[,1]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,1]),digits=3)," (",round(min(dta2[,1]),digits=2),", ",round(max(dta2[,1]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,1])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,1])+(mean(dta2[,1])-0.8)^2),digits=3))
				    )
  kk2 <- data.frame(P1 = paste0(round(mean(dta1[,2]),digits=3)," (",round(sd(dta1[,2]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,2]),digits=3)," (",round(min(dta1[,2]),digits=2),", ",round(max(dta1[,2]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,2])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,2])+(mean(dta1[,2])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,2]),digits=3)," (",round(sd(dta2[,2]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,2]),digits=3)," (",round(min(dta2[,2]),digits=2),", ",round(max(dta2[,2]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,2])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,2])+(mean(dta2[,2])-0.8)^2),digits=3))
				    )
  kk3 <- data.frame(P1 = paste0(round(mean(dta1[,3]),digits=3)," (",round(sd(dta1[,3]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,3]),digits=3)," (",round(min(dta1[,3]),digits=2),", ",round(max(dta1[,3]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,3])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,3])+(mean(dta1[,3])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,3]),digits=3)," (",round(sd(dta2[,3]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,3]),digits=3)," (",round(min(dta2[,3]),digits=2),", ",round(max(dta2[,3]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,3])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,3])+(mean(dta2[,3])-0.8)^2),digits=3))
				    )
  kk4 <- data.frame(P1 = paste0(round(mean(dta1[,4]),digits=3)," (",round(sd(dta1[,4]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,4]),digits=3)," (",round(min(dta1[,4]),digits=2),", ",round(max(dta1[,4]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,4])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,4])+(mean(dta1[,4])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,4]),digits=3)," (",round(sd(dta2[,4]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,4]),digits=3)," (",round(min(dta2[,4]),digits=2),", ",round(max(dta2[,4]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,4])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,4])+(mean(dta2[,4])-0.8)^2),digits=3))
				    )
  kk5 <- data.frame(P1 = paste0(round(mean(dta1[,5]),digits=3)," (",round(sd(dta1[,5]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,5]),digits=3)," (",round(min(dta1[,5]),digits=2),", ",round(max(dta1[,5]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,5])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,5])+(mean(dta1[,5])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,5]),digits=3)," (",round(sd(dta2[,5]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,5]),digits=3)," (",round(min(dta2[,5]),digits=2),", ",round(max(dta2[,5]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,5])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,5])+(mean(dta2[,5])-0.8)^2),digits=3))
				    )
  kk6 <- data.frame(P1 = paste0(round(mean(dta1[,6]),digits=3)," (",round(sd(dta1[,6]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,6]),digits=3)," (",round(min(dta1[,6]),digits=2),", ",round(max(dta1[,6]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,6])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,6])+(mean(dta1[,6])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,6]),digits=3)," (",round(sd(dta2[,6]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,6]),digits=3)," (",round(min(dta2[,6]),digits=2),", ",round(max(dta2[,6]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,6])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,6])+(mean(dta2[,6])-0.8)^2),digits=3))
				    )
  kk7 <- data.frame(P1 = paste0(round(mean(dta1[,7]),digits=3)," (",round(sd(dta1[,7]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,7]),digits=3)," (",round(min(dta1[,7]),digits=2),", ",round(max(dta1[,7]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,7])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,7])+(mean(dta1[,7])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,7]),digits=3)," (",round(sd(dta2[,7]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,7]),digits=3)," (",round(min(dta2[,7]),digits=2),", ",round(max(dta2[,7]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,7])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,7])+(mean(dta2[,7])-0.8)^2),digits=3))
				    )
  kk8 <- data.frame(P1 = paste0(round(mean(dta1[,8]),digits=3)," (",round(sd(dta1[,8]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,8]),digits=3)," (",round(min(dta1[,8]),digits=2),", ",round(max(dta1[,8]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,8])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,8])+(mean(dta1[,8])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,8]),digits=3)," (",round(sd(dta2[,8]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,8]),digits=3)," (",round(min(dta2[,8]),digits=2),", ",round(max(dta2[,8]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,8])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,8])+(mean(dta2[,8])-0.8)^2),digits=3))
				    )
  kk9 <- data.frame(P1 = paste0(round(mean(dta1[,9]),digits=3)," (",round(sd(dta1[,9]),digits=3),")"),
				    P2 = paste0(round(median(dta1[,9]),digits=3)," (",round(min(dta1[,9]),digits=2),", ",round(max(dta1[,9]),digits=2),")"),
				    P3 = paste0(round(mean(dta1[,9])-0.8,digits=3)),
				    P4 = paste0(round(sqrt(var(dta1[,9])+(mean(dta1[,9])-0.8)^2),digits=3)),
				    P5 = paste0(round(mean(dta2[,9]),digits=3)," (",round(sd(dta2[,9]),digits=3),")"),
				    P6 = paste0(round(median(dta2[,9]),digits=3)," (",round(min(dta2[,9]),digits=2),", ",round(max(dta2[,9]),digits=2),")"),
				    P7 = paste0(round(mean(dta2[,9])-0.8,digits=3)),
				    P8 = paste0(round(sqrt(var(dta2[,9])+(mean(dta2[,9])-0.8)^2),digits=3))
				    )
  return(rbind(kk1,kk2,kk3,kk4,kk5,kk6,kk7,kk8,kk9))
}


latex(sum_func(data_siv_500,data_siv_2000),file="~/Desktop/D_Orihara/Simulation_IVselect/kekka/kk_sum_strongIV")
latex(sum_func(data_wiv_500,data_wiv_2000),file="~/Desktop/D_Orihara/Simulation_IVselect/kekka/kk_sum_weakIV")








