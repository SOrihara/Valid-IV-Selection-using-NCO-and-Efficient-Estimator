

library(MASS)
#rm(list = ls(all.names = TRUE))

#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_strong_IV")
#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_weak_IV")

nn <- 1000
KK <- 1000
est <- matrix(0,ncol=KK,nrow=3)


for(mm in 1:KK){
data_anl <- subset(data1,data1[,1]<=nn&data1[,9]==mm)

#Variables
TT <- data_anl[,2]
ZZ1 <- data_anl[,3]; ZZ21 <- data_anl[,4]; ZZ22 <- data_anl[,5]
YY <- data_anl[,6]


#GMM (ordinary)
TT_1 <- cbind(1,TT)

##Detect true IVs
GMM_vec1 <- cbind(1,ZZ1,ZZ22)

##Efficient weight
WW_1 <- t(GMM_vec1)%*%GMM_vec1

##Estimate
beta_GMM <- solve(t(TT_1)%*%GMM_vec1%*%solve(WW_1)%*%t(GMM_vec1)%*%TT_1)%*%t(TT_1)%*%GMM_vec1%*%solve(WW_1)%*%t(GMM_vec1)%*%YY

#Liao, 2013
Min_func <- function(beta){
  theta <- beta[1:2]; beta <- beta[3]
  
  GMM_vec <- cbind(1,ZZ1,ZZ22,ZZ21)

  ##Efficient weight
  WW <- t(GMM_vec)%*%GMM_vec

  ##Estimating equation
  rho <- (t(GMM_vec)%*%(YY-TT_1%*%theta)-c(rep(0,3),beta))/sqrt(nn)
  
  ##Adaptive LASSO
  LF <- t(rho)%*%WW%*%rho+0.5*nn*(abs(beta)/(abs(beta)^1))
  return(LF)
}
#optim(rep(0.1,3),Min_func)
beta_Li <- optim(rep(0.1,3),Min_func)$par[1:2]


#DiTraglia, 2016
##True parameters are estimated by GMM as above.
mu <- TT_1%*%beta_GMM

##True momoent conditions
GMM_vec_TT <- cbind(1,ZZ1,ZZ22)
GMM_vec_FF <- ZZ21
GMM_vec_all <- cbind(1,ZZ1,ZZ22,ZZ21)

WWv <- t(GMM_vec_TT)%*%GMM_vec_TT
Kv <- solve(t(TT_1)%*%GMM_vec_TT%*%WWv%*%t(t(TT_1)%*%GMM_vec_TT))%*%t(TT_1)%*%GMM_vec_TT%*%WWv
Omega <- (t(GMM_vec_all)*c(YY-mu))%*%t(t(GMM_vec_all)*c(YY-mu))/nn-(t(GMM_vec_all)%*%(YY-mu)/nn)%*%t(t(GMM_vec_all)%*%(YY-mu))/nn

tau <- sqrt(nn)*t(GMM_vec_FF)%*%(YY-mu)/nn
HH <- -t(GMM_vec_FF)%*%TT_1/nn
Psi <- cbind(-HH%*%Kv,1)

MM_p <- tau^2-Psi%*%Omega%*%t(Psi)


FMSC_func <- function(ZZ,Xi,FP){
GMM_vec <- ZZ
WWS <- t(GMM_vec)%*%GMM_vec 
KS <- solve(t(TT_1)%*%GMM_vec%*%WWS%*%t(t(TT_1)%*%GMM_vec))%*%t(TT_1)%*%GMM_vec%*%WWS

beta_DT <- solve(t(TT_1)%*%GMM_vec%*%solve(WWS)%*%t(GMM_vec)%*%TT_1)%*%t(TT_1)%*%GMM_vec%*%solve(WWS)%*%t(GMM_vec)%*%YY
FMSC <- FP%*%KS%*%Xi%*%(Omega+diag(c(1,1,1,MM_p)))%*%t(FP%*%KS%*%Xi)
return(list(beta_DT,FMSC))
}


xi1 <- c(1,0,0,0,0,1,0,0,0,0,1,0); Xi1 <- matrix(xi1,nrow=3,byrow=T)
xi2 <- c(1,0,0,0,0,1,0,0,0,0,0,1); Xi2 <- matrix(xi2,nrow=3,byrow=T)
xi3 <- c(1,0,0,0,0,0,1,0,0,0,0,1); Xi3 <- matrix(xi3,nrow=3,byrow=T)
xi4 <- diag(4); Xi4 <- matrix(xi4,nrow=4,byrow=T)

FIC1 <- FMSC_func(cbind(1,ZZ1,ZZ22),Xi1,FP=c(1,1))
FIC2 <- FMSC_func(cbind(1,ZZ1,ZZ21),Xi2,FP=c(1,1))
FIC3 <- FMSC_func(cbind(1,ZZ22,ZZ21),Xi3,FP=c(1,1))
FIC4 <- FMSC_func(cbind(1,ZZ1,ZZ22,ZZ21),Xi4,FP=c(1,1))

FIC_best <- order(c(FIC1[[2]],FIC2[[2]],FIC3[[2]],FIC4[[2]]))[1]
beta_DT <- cbind(FIC1[[1]],FIC2[[1]],FIC3[[1]],FIC4[[1]])[,FIC_best]

##Summarize all methods:
est[,mm]=c(beta_GMM[2],beta_Li[2],beta_DT[2])

if(mm%%100==0) print(mm)
}


apply(est,1,mean); apply(est,1,sd)
apply(est,1,quantile)
sqrt(apply(est,1,var)+(apply(est,1,mean)-0.8)^2)

kk <- list(est[1,],est[2,],est[3,])
names(kk) <- c("GMM\n(unspecify)","Liao, 2013\n(unspecify)","DiTraglia, 2016\n(unspecify)")

#par(mfcol=c(1,4))
#hist(kk[[1]]); hist(kk[[2]]); hist(kk[[3]]); hist(kk[[4]])

boxplot(kk)

write.csv(est,"~/Desktop/D_Orihara/Simulation_IVselect/kekka/kekka_unspecify_n1000_1",row.names=F)



