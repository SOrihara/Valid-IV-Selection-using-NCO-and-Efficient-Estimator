

library(MASS)
rm(list = ls(all.names = TRUE))

nn=5000
set.seed(20211219)

for(kk in 1:1000){

#Parameters
##The settings are the same as Liao, 2013
matrix_vec <- c(1,  0.4,0.4,0.4,0,
                0.4,1,  0,  0,  0,
                0.4,0,  1,  0,  0,
                0.4,0,  0,  1,  0,
                0,  0,  0,  0,  1)
Sigma=matrix(matrix_vec,ncol=5)
XX=mvrnorm(nn,mu=rep(0,5),Sigma=Sigma)

TT <- XX[,1]
UU <- XX[,4]
ZZ1 <- XX[,2]
ZZ21 <- XX[,3]; ZZ22 <- XX[,5]+0.5*UU

#Outcome
YY=0.8+0.8*TT+UU

#NCOs (Strong & weak)
##The settings are the same as Miao & Tchetgen Tchetgen, 2018
ee <- rnorm(nn,sd=1)
MM_s <- 1+1*UU+ee
MM_w <- 1+0.35*UU+ee

#> cor(UU,cbind(MM_s,MM_w))
#          MM_s      MM_w
#[1,] 0.7129169 0.3409779
#> cor(cbind(ZZ1,ZZ21,ZZ22),cbind(MM_s,MM_w))
#            MM_s        MM_w
#ZZ1  0.002933549 0.003501959
#ZZ21 0.018934844 0.020829740
#ZZ22 0.317333668 0.152523042


#Sample ID
ID <- 1:nn

inst_data <- cbind(ID,TT,ZZ1,ZZ21,ZZ22,YY,MM_s,MM_w,kk)

if(kk==1) inst_data2 <- inst_data
else inst_data2 <- rbind(inst_data2,inst_data)
}

write.csv(inst_data2,"~/Desktop/D_Orihara/Simulation_IVselect/Inst_data_strong_IV",row.names=F)


